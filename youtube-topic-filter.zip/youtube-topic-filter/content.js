const searchParams = new URLSearchParams(window.location.search);
const query = searchParams.get("search_query")?.toLowerCase();

console.log("Filtering for:", query);

const filterVideos = () => {
  const videos = document.querySelectorAll('ytd-video-renderer');

  videos.forEach(video => {
    const titleElement = video.querySelector('#video-title');
    const title = titleElement?.textContent?.toLowerCase() || "";

    if (!title.includes(query)) {
      video.style.display = "none";
    } else {
      video.style.display = "block";
    }
  });
};

// Use MutationObserver to wait for YouTube to fully load
const observer = new MutationObserver(() => {
  filterVideos();
});

const resultsContainer = document.querySelector('ytd-item-section-renderer');

if (resultsContainer) {
  observer.observe(resultsContainer, { childList: true, subtree: true });
}
